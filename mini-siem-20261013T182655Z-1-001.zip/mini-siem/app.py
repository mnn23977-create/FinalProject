from flask import Flask, render_template, request, redirect, url_for
from database.models import db, LogEntry, Alert
from core.collector import parse_logs
from core.rule_engine import check_brute_force
from datetime import datetime, timedelta
import random
import os

app = Flask(__name__, template_folder='web/templates')
app.secret_key = 'super_secret_key_for_siem'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///siem.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# 1. موقع الشركة الرسمي (SmartNet Enterprise Home)
@app.route('/')
def company_home():
    client_ip = request.remote_addr
    log_line = f"PAGE_VIEW - IP:{client_ip} - User:Visitor - Status: Authorized\n"
    with open('system.log', 'a') as f:
        f.write(log_line)
    return render_template('company_home.html')

# 2. زر محاكاة هجوم DDoS
@app.route('/simulate-ddos')
def simulate_ddos():
    attacker_ip = "192.168.100.99"
    with open('system.log', 'a') as f:
        for _ in range(15):
            f.write(f"FLOOD_REQUEST - IP:{attacker_ip} - User:BotNet - Status: Blocked\n")
    return redirect(url_for('dashboard'))

# 3. لوحة تحكم عمليات الأمان (SOC Dashboard)
@app.route('/dashboard')
def dashboard():
    logs_data = parse_logs()
    detected_alerts = check_brute_force(logs_data)
    
    with app.app_context():
        new_alert_detected = False
        for alert_info in detected_alerts:
            existing = Alert.query.filter_by(description=alert_info['description']).first()
            if not existing:
                new_alert = Alert(
                    alert_type=alert_info['alert_type'],
                    description=alert_info['description'],
                    severity=alert_info['severity'],
                    timestamp=alert_info['timestamp'],
                    created_at=datetime.now()
                )
                db.session.add(new_alert)
                new_alert_detected = True
                
        db.session.commit()
        
        if new_alert_detected:
            try:
                with open('system.log', 'w') as log_file:
                    log_file.write("")
            except:
                pass
        
        five_minutes_ago = datetime.now() - timedelta(minutes=5)
        recent_alerts = Alert.query.filter(Alert.created_at >= five_minutes_ago).order_by(Alert.id.desc()).all()
        
        all_stored_alerts = Alert.query.order_by(Alert.id.desc()).all()
        total_logs = len(logs_data)
        failed_count = sum(1 for log in logs_data if log['status'] == 'FAILED_LOGIN')
        alerts_count = len(all_stored_alerts)

    return render_template(
        'dashboard.html', 
        logs=logs_data, 
        alerts=recent_alerts, 
        total_logs=total_logs,
        failed_count=failed_count,
        alerts_count=alerts_count
    )

# 4. صفحة سجل التنبيهات الخاصة (الأرشيف)
@app.route('/alerts')
def alerts_page():
    with app.app_context():
        all_alerts = Alert.query.order_by(Alert.id.desc()).all()
    return render_template('alerts.html', alerts=all_alerts)

# 5. بوابة تسجيل الدخول للشركة
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        client_ip = request.remote_addr
        
        # بيانات الدخول الصحيحة (يمكنك تغييرها كما ترغب)
        if username == 'admin' and password == 'admin123':
            log_line = f"SUCCESS - IP:{client_ip} - User:{username} - Status: Authorized\n"
            with open('system.log', 'a') as f:
                f.write(log_line)
            # عند نجاح تسجيل الدخول، يتم تحويل المستخدم إلى موقع الشركة الرئيسي
            return redirect(url_for('company_home'))
        else:
            log_line = f"FAILED_LOGIN - IP:{client_ip} - User:{username} - Pass:{password} - Status: Unauthorized\n"
            with open('system.log', 'a') as f:
                f.write(log_line)
            error = "اسم المستخدم أو كلمة المرور غير صحيحة، أعد المحاولة!"
            
    return render_template('login.html', error=error)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)