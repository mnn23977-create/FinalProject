from collections import defaultdict
from datetime import datetime

def check_brute_force(logs):
    failed_attempts = defaultdict(list)
    ip_request_counts = defaultdict(int)
    
    failed_logs = [log for log in logs if log['status'] == 'FAILED_LOGIN']
    recent_logs = failed_logs[-3:] if len(failed_logs) >= 3 else []
    
    for log in recent_logs:
        ip = log['ip']
        user = log['user']
        password = log.get('password', '')
        failed_attempts[ip].append({'user': user, 'pass': password})
            
    # فحص إجمالي الطلبات لكل IP بغض النظر عن الحالة لكشف هجمات الـ DDoS
    for log in logs:
        ip = log.get('ip')
        if ip:
            ip_request_counts[ip] += 1
            
    alerts = []
    
    # 1. كشف هجمات Brute Force
    for ip, attempts in failed_attempts.items():
        if len(attempts) >= 3:
            tried_users = set(a['user'] for a in attempts)
            tried_passes = set(a['pass'] for a in attempts if a['pass'])
            
            description = (
                f"تم رصد هجوم Brute Force من الآيبي ({ip}). "
                f"| المستخدمون: {list(tried_users)} | الكلمات المخمنة: {list(tried_passes)}"
            )
            
            alerts.append({
                'alert_type': 'Brute Force Attack',
                'description': description,
                'severity': 'High (خطير جداً)',
                'timestamp': datetime.now().strftime("%H:%M:%S %d-%m-%Y")
            })

    # 2. كشف هجمات DDoS (إذا أرسل آيبي معين طلبات متطرفة وكثيرة)
    for ip, count in ip_request_counts.items():
        if count >= 12: # إذا تجاوز عدد الطلبات الحد الطبيعي
            description = (
                f"تم رصد هجوم حجب خدمة موزع (DDoS Attack) قادم من الآيبي ({ip}) "
                f"بمعدل تدفق هائل بلغ {count} طلب في نافذة المراقبة الحالية!"
            )
            # تجنب تكرار نفس التنبيه لنفس الآيبي في نفس اللحظة
            if not any(a['description'].find(ip) != -1 and 'DDoS' in a['alert_type'] for a in alerts):
                alerts.append({
                    'alert_type': 'DDoS Attack (Flood)',
                    'description': description,
                    'severity': 'Critical (حرج للغاية)',
                    'timestamp': datetime.now().strftime("%H:%M:%S %d-%m-%Y")
                })
            
    return alerts