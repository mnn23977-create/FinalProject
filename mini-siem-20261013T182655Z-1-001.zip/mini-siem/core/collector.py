os = __import__('os')

def parse_logs():
    logs = []
    log_file_path = 'system.log'
    
    if not os.path.exists(log_file_path):
        return logs

    with open(log_file_path, 'r') as f:
        for line in f:
            parts = line.strip().split(' - ')
            status = ""
            ip = "Unknown"
            user = "Unknown"
            password = ""
            timestamp = ""
            
            for part in parts:
                if "SUCCESS" in part or "FAILED_LOGIN" in part:
                    status = part.split(' - ')[0]
                elif "IP:" in part:
                    ip = part.replace("IP:", "").strip()
                elif "User:" in part:
                    user = part.replace("User:", "").strip()
                elif "Pass:" in part:
                    password = part.replace("Pass:", "").strip()
                elif ":" in part and len(part) == 8 and part[2] == ':' and part[5] == ':': # التقط الوقت لو موجود
                    pass
            
            # استخراج وقت التعديل الفعلي للسطر أو حفظ وقت النظام الحالي كطابع زمني دقيق للمحاولة
            from datetime import datetime
            timestamp = datetime.now().strftime("%H:%M:%S %d-%m-%Y")
            
            logs.append({
                'status': status,
                'ip': ip,
                'user': user,
                'password': password,
                'timestamp': timestamp
            })
            
    return logs