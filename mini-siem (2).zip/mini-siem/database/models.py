from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class LogEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    timestamp = db.Column(
        db.String(50),
        default=lambda: datetime.now().strftime("%H:%M:%S %d-%m-%Y"),
    )

    status = db.Column(db.String(50))
    ip = db.Column(db.String(50))
    user = db.Column(db.String(50))
    password = db.Column(db.String(100))


class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    alert_type = db.Column(db.String(100))
    description = db.Column(db.Text)
    severity = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))

    # وقت إنشاء التنبيه لا يتغير عند تحديثه.
    created_at = db.Column(db.DateTime, default=datetime.now)

    source_ip = db.Column(db.String(50))
    state = db.Column(db.String(20), default="new")

    updated_at = db.Column(db.DateTime, default=datetime.now)
    closed_at = db.Column(db.DateTime)

    first_seen = db.Column(db.DateTime)
    last_seen = db.Column(db.DateTime)

    # عدد الأحداث في نافذة الكشف عند آخر تحديث.
    attempt_count = db.Column(db.Integer, default=0)