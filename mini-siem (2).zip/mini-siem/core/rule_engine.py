
from collections import defaultdict
from datetime import datetime, timedelta


WINDOW_SECONDS = 60

RULES = {
    "FAILED_LOGIN": {
        "type": "Brute Force Attack",
        "threshold": 3,
        "severity": "High (مرتفع)",
    },
    "FLOOD_REQUEST": {
        "type": "DDoS Simulation",
        "threshold": 15,
        "severity": "High (مرتفع)",
    },
}


def check_brute_force(logs, closed_after=None, now=None):
    now = now or datetime.now()
    cutoff = now - timedelta(seconds=WINDOW_SECONDS)
    closed_after = closed_after or {}

    grouped = defaultdict(list)

    for log in logs:
        rule = RULES.get(log.get("status"))
        ip = log.get("ip")
        event_time = log.get("event_time")

        if not rule or not ip or not isinstance(event_time, datetime):
            continue

        # Only analyze events within the last 60 seconds
        if not cutoff <= event_time <= now:
            continue

        key = (rule["type"], ip)
        closed_time = closed_after.get(key)

        # Ignore events that occurred before alert closure
        if closed_time and event_time <= closed_time:
            continue

        grouped[key].append(log)

    alerts = []

    for (alert_type, ip), events in grouped.items():
        rule = RULES[events[0]["status"]]

        if len(events) < rule["threshold"]:
            continue

        events.sort(key=lambda event: event["event_time"])

        first_seen = events[0]["event_time"]
        last_seen = events[-1]["event_time"]
        attempt_count = len(events)

        users = sorted({
            event.get("user")
            for event in events
            if event.get("user")
        })

        # Brute Force severity classification
        if alert_type == "Brute Force Attack":

            if attempt_count >= 5:
                severity = "High (مرتفع)"
                summary = "اشتباه قوي في هجوم Brute Force"

            else:
                severity = "Medium (متوسط)"
                summary = "اشتباه في محاولات Brute Force"

        # Keep DDoS detection unchanged
        else:
            severity = rule["severity"]
            summary = "محاكاة DDoS محلية"

        description = (
            f"{summary} من الآيبي ({ip}). "
            f"| عدد الأحداث خلال آخر {WINDOW_SECONDS} ثانية: {attempt_count} "
            f"| أول حدث: {first_seen:%H:%M:%S %d-%m-%Y} "
            f"| آخر حدث: {last_seen:%H:%M:%S %d-%m-%Y} "
            f"| المستخدمون: {', '.join(users)}"
        )

        alerts.append({
            "alert_type": alert_type,
            "ip_source": ip,
            "severity": severity,
            "description": description,
            "timestamp": last_seen.strftime("%H:%M:%S %d-%m-%Y"),
            "first_seen": first_seen,
            "last_seen": last_seen,
            "attempt_count": attempt_count,
        })

    return alerts
