from pathlib import Path
from datetime import datetime

LOG_FILE = Path("system.log")


def parse_logs():
    logs = []

    if not LOG_FILE.exists():
        return logs

    with LOG_FILE.open("r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()

            if not line:
                continue

            parts = line.split(" - ")
            event_time = None

            # قراءة وقت الحدث، مع دعم السجلات القديمة بدون وقت.
            try:
                event_time = datetime.fromisoformat(parts[0])
                parts = parts[1:]
            except ValueError:
                pass

            if not parts:
                continue

            status = parts[0].strip().upper()

            if "FAIL" in status:
                status = "FAILED_LOGIN"

            entry = {
                "raw": line,
                "status": status,
                "ip": "",
                "user": "",
                "password": "",
                "event_time": event_time,
            }

            for part in parts[1:]:
                key, separator, value = part.partition(":")

                if not separator:
                    continue

                key = key.strip()
                value = value.strip()

                if key == "IP":
                    entry["ip"] = value
                elif key == "User":
                    entry["user"] = value

            logs.append(entry)

    return logs