import time
import random

ip_addresses = ["192.168.1.50", "10.0.0.15", "172.16.0.8", "203.0.113.5"]
users = ["admin", "root", "user1", "test"]

def generate_logs():
    print("[*] Generating simulation logs... Press Ctrl+C to stop.")
    while True:
        ip = random.choice(ip_addresses)
        user = random.choice(users)
        
        if ip == "203.0.113.5":
            log_line = f"FAILED_LOGIN - IP:{ip} - User:{user} - Status: Unauthorized\n"
        else:
            status = random.choice(["SUCCESS", "FAILED_LOGIN"])
            log_line = f"{status} - IP:{ip} - User:{user} - Status: OK\n"
            
        with open("system.log", "a") as f:
            f.write(log_line)
            
        time.sleep(2)

if __name__ == "__main__":
    generate_logs()