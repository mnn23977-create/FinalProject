from pathlib import Path
from datetime import datetime, timedelta
from functools import wraps
from getpass import getpass

import json
import os
import secrets
import sqlite3

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    abort,
)
from sqlalchemy import inspect, text
from werkzeug.security import generate_password_hash, check_password_hash

from database.models import db, Alert
from core.collector import parse_logs
from core.rule_engine import check_brute_force


BASE_DIR = Path(__file__).resolve().parent
os.chdir(BASE_DIR)

app = Flask(
    __name__,
    template_folder=str(BASE_DIR / "web" / "templates"),
)

INSTANCE_DIR = Path(app.instance_path)
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)

SECRET_FILE = INSTANCE_DIR / "session_secret.key"
ADMIN_FILE = INSTANCE_DIR / "admin_credentials.json"

LOG_FILE = BASE_DIR / "system.log"
OPEN_STATES = ("new", "investigating")


def load_secret_key():
    if not SECRET_FILE.exists():
        try:
            with SECRET_FILE.open("x", encoding="utf-8") as file:
                file.write(secrets.token_hex(32))
        except FileExistsError:
            pass

    return SECRET_FILE.read_text(encoding="utf-8").strip()


app.secret_key = load_secret_key()

app.config.update(
    SQLALCHEMY_DATABASE_URI="sqlite:///siem.db",
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),
    SESSION_REFRESH_EACH_REQUEST=False,
)

# التطبيق المحلي يعمل عبر HTTP.
# عند نشره عبر HTTPS يجب تفعيل SESSION_COOKIE_SECURE.
db.init_app(app)


def setup_admin():
    if ADMIN_FILE.exists():
        return

    print("\nCreate the SIEM administrator account.")
    print("Username: admin")

    while True:
        password = getpass("New password (at least 12 characters): ")
        confirmation = getpass("Confirm password: ")

        if len(password) < 12:
            print("Password must contain at least 12 characters.")
            continue

        if password != confirmation:
            print("Passwords do not match.")
            continue

        credentials = {
            "username": "admin",
            "password_hash": generate_password_hash(password),
        }

        with ADMIN_FILE.open("x", encoding="utf-8") as file:
            json.dump(credentials, file)

        print("Administrator account created.\n")
        break


def read_admin():
    if not ADMIN_FILE.exists():
        return None

    return json.loads(ADMIN_FILE.read_text(encoding="utf-8"))


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("is_admin") is not True:
            return redirect(url_for("admin_login"))

        return view(*args, **kwargs)

    return wrapped


def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(32)

    return session["csrf_token"]


def validate_csrf():
    submitted = request.form.get("csrf_token", "")
    expected = session.get("csrf_token", "")

    if not expected or not secrets.compare_digest(submitted, expected):
        abort(400, description="حدّث الصفحة ثم أعد المحاولة.")


app.jinja_env.globals["csrf_token"] = csrf_token


def upgrade_database():
    db.create_all()

    existing_columns = {
        column["name"]
        for column in inspect(db.engine).get_columns("alert")
    }

    additions = {
        "source_ip": "VARCHAR(50)",
        "state": "VARCHAR(20) DEFAULT 'archived'",
        "updated_at": "DATETIME",
        "closed_at": "DATETIME",
        "first_seen": "DATETIME",
        "last_seen": "DATETIME",
        "attempt_count": "INTEGER DEFAULT 0",
    }

    missing = {
        name: sql_type
        for name, sql_type in additions.items()
        if name not in existing_columns
    }

    if not missing:
        return

    database_path = Path(db.engine.url.database)
    backup_path = database_path.with_name(
        database_path.name
        + ".backup-"
        + datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    )

    with sqlite3.connect(str(database_path)) as source:
        with sqlite3.connect(str(backup_path)) as destination:
            source.backup(destination)

    with db.engine.begin() as connection:
        for name, sql_type in missing.items():
            connection.execute(
                text(f"ALTER TABLE alert ADD COLUMN {name} {sql_type}")
            )

        connection.execute(text("""
            UPDATE alert
            SET updated_at = created_at
            WHERE updated_at IS NULL
        """))

    print(f"Database backup saved: {backup_path}")


def clean_log_value(value):
    return (
        str(value or "")
        .replace("\r", " ")
        .replace("\n", " ")
        .replace(" - ", " ")
        .strip()
    )


def write_log(status, ip, username, result):
    event_time = datetime.now().isoformat(timespec="microseconds")

    line = (
        f"{event_time} - {clean_log_value(status)}"
        f" - IP:{clean_log_value(ip)}"
        f" - User:{clean_log_value(username)}"
        f" - Status:{clean_log_value(result)}\n"
    )

    with LOG_FILE.open("a", encoding="utf-8") as file:
        file.write(line)


def severity_rank(value):
    """ترتيب مستويات الخطورة للمحافظة على أعلى مستوى للتنبيه المفتوح."""
    level = str(value or "").split("(", 1)[0].strip().lower()
    return {
        "low": 1,
        "medium": 2,
        "high": 3,
        "critical": 4,
    }.get(level, 0)


def update_alerts(logs_data):
    closed_after = {}

    closed_alerts = Alert.query.filter(
        Alert.state == "closed",
        Alert.closed_at.isnot(None),
        Alert.source_ip.isnot(None),
    ).all()

    for alert in closed_alerts:
        key = (alert.alert_type, alert.source_ip)
        previous = closed_after.get(key)

        if previous is None or alert.closed_at > previous:
            closed_after[key] = alert.closed_at

    detected = check_brute_force(
        logs_data,
        closed_after=closed_after,
    )

    for item in detected:
        existing = (
            Alert.query.filter(
                Alert.alert_type == item["alert_type"],
                Alert.source_ip == item["ip_source"],
                Alert.state.in_(OPEN_STATES),
            )
            .order_by(Alert.id.desc())
            .first()
        )

        now = datetime.now()

        if existing is None:
            db.session.add(Alert(
                alert_type=item["alert_type"],
                source_ip=item["ip_source"],
                description=item["description"],
                severity=item["severity"],
                timestamp=item["timestamp"],
                created_at=now,
                updated_at=now,
                state="new",
                first_seen=item["first_seen"],
                last_seen=item["last_seen"],
                attempt_count=item["attempt_count"],
            ))

        elif (
            existing.last_seen is None
            or item["last_seen"] > existing.last_seen
        ):
            # حدّث تفاصيل الكشف الجديد، لكن لا تُخفّض خطورة تنبيه مفتوح
            # إذا سبق وصوله إلى High ثم خرجت محاولات قديمة من نافذة الـ60 ثانية.
            new_severity = item["severity"]
            old_severity = existing.severity

            if severity_rank(new_severity) >= severity_rank(old_severity):
                existing.severity = new_severity
                existing.description = item["description"]
            else:
                existing.description = (
                    item["description"]
                    + f" | أعلى خطورة رُصدت لهذا التنبيه: {old_severity}"
                )

            existing.timestamp = item["timestamp"]
            existing.last_seen = item["last_seen"]
            existing.attempt_count = item["attempt_count"]
            existing.updated_at = now

            if existing.first_seen is None:
                existing.first_seen = item["first_seen"]

    db.session.commit()


# تسجيل دخول المسؤول، مستقل عن تسجيل الدخول التجريبي.
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if session.get("is_admin") is True:
        return redirect(url_for("dashboard"))

    error = None

    if request.method == "POST":
        validate_csrf()

        credentials = read_admin()

        if credentials is None:
            abort(503, description="شغّل python app.py لإعداد حساب المسؤول.")

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        password_valid = check_password_hash(
            credentials["password_hash"],
            password,
        )

        if username == credentials["username"] and password_valid:
            session.clear()
            session["is_admin"] = True
            session["admin_username"] = username
            session.permanent = True

            write_log(
                "ADMIN_LOGIN_SUCCESS",
                request.remote_addr or "unknown",
                username,
                "Authorized",
            )

            return redirect(url_for("dashboard"))

        write_log(
            "ADMIN_LOGIN_FAILED",
            request.remote_addr or "unknown",
            username,
            "Unauthorized",
        )

        error = "اسم المستخدم أو كلمة المرور غير صحيحة."

    return render_template("admin_login.html", error=error)


@app.route("/admin/logout", methods=["POST"])
@admin_required
def admin_logout():
    validate_csrf()

    write_log(
        "ADMIN_LOGOUT",
        request.remote_addr or "unknown",
        session.get("admin_username", "admin"),
        "Completed",
    )

    session.clear()

    return redirect(url_for("admin_login"))


@app.route("/")
def company_home():
    write_log(
        "PAGE_VIEW",
        request.remote_addr or "unknown",
        "Visitor",
        "Authorized",
    )

    return render_template("company_home.html")


# أصبح POST لأن تشغيل المحاكاة يضيف بيانات.
@app.route("/simulate-ddos", methods=["POST"])
@admin_required
def simulate_ddos():
    validate_csrf()

    for _ in range(15):
        write_log(
            "FLOOD_REQUEST",
            "192.168.100.99",
            "BotNet",
            "Simulated",
        )

    update_alerts(parse_logs())

    return redirect(url_for("dashboard"))


@app.route("/dashboard")
@admin_required
def dashboard():
    logs_data = parse_logs()
    update_alerts(logs_data)

    active_alerts = (
        Alert.query.filter(Alert.state.in_(OPEN_STATES))
        .order_by(Alert.updated_at.desc(), Alert.id.desc())
        .all()
    )

    return render_template(
        "dashboard.html",
        logs=logs_data,
        alerts=active_alerts,
        total_logs=len(logs_data),
        failed_count=sum(
            1 for log in logs_data
            if log.get("status") == "FAILED_LOGIN"
        ),
        alerts_count=Alert.query.count(),
    )


@app.route("/alerts")
@admin_required
def alerts_page():
    update_alerts(parse_logs())

    all_alerts = (
        Alert.query
        .order_by(Alert.updated_at.desc(), Alert.id.desc())
        .all()
    )

    return render_template("alerts.html", alerts=all_alerts)


@app.route("/alerts/<int:alert_id>/state", methods=["POST"])
@admin_required
def change_alert_state(alert_id):
    validate_csrf()
    update_alerts(parse_logs())

    alert = db.session.get(Alert, alert_id)

    if alert is None:
        abort(404)

    requested_state = request.form.get("state")

    allowed_transitions = {
        "new": {"investigating", "closed"},
        "investigating": {"closed"},
    }

    if requested_state not in allowed_transitions.get(alert.state, set()):
        abort(400, description="هذا التغيير غير متاح لحالة التنبيه.")

    now = datetime.now()
    alert.state = requested_state
    alert.updated_at = now

    if requested_state == "closed":
        alert.closed_at = now

    db.session.commit()

    return redirect(url_for("alerts_page"))


# صفحة اختبار محاولات الدخول.
# نجاح الدخول هنا لا يمنح صلاحية مسؤول النظام.
@app.route("/login", methods=["GET", "POST"])
def login():
    error = None

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        client_ip = request.remote_addr or "unknown"

        valid_login = (
            (username == "admin" and password == "admin123")
            or
            (username == "يوسف" and password == "yousef2026")
        )

        write_log(
            "SUCCESS" if valid_login else "FAILED_LOGIN",
            client_ip,
            username,
            "Authorized" if valid_login else "Unauthorized",
        )

        update_alerts(parse_logs())

        if valid_login:
            return redirect(url_for("company_home"))

        error = "اسم المستخدم أو كلمة المرور غير صحيحة، أعد المحاولة."

    return render_template("login.html", error=error)


with app.app_context():
    upgrade_database()


if __name__ == "__main__":
    setup_admin()

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False,
    )