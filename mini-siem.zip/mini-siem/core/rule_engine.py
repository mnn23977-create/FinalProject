from collections import defaultdict
from datetime import datetime

def check_brute_force(logs):
    failed_attempts = defaultdict(list)
    ip_request_counts = defaultdict(int)
    
    recent_logs = logs[-40:] if len(logs) > 40 else logs
    
    for log in recent_logs:
        ip = log.get('ip')
        status = log.get('status')
        user = log.get('user', '')
        password = log.get('password', '')
        
        if ip:
            ip_request_counts[ip] += 1
            
        if status == 'FAILED_LOGIN' and ip:
            failed_attempts[ip].append({'user': user, 'pass': password})
            
    alerts = []
    
    # كشف هجوم Brute Force مع تسجيل عدد المرات ووقت آخر محاولة
    for ip, attempts in failed_attempts.items():
        if len(attempts) >= 3:
            tried_users = set(a['user'] for a in attempts)
            tried_passes = set(a['pass'] for a in attempts if a['pass'])
            attempt_count = len(attempts)
            last_time = datetime.now().strftime("%H:%M:%S %d-%m-%Y")
            
            description = (
                f"هجوم Brute Force نشط من الآيبي ({ip}). "
                f"| عدد المحاولات الفاشلة: {attempt_count} مرات "
                f"| آخر محاولة: {last_time} "
                f"| المستخدمون: {list(tried_users)} | الكلمات المخمنة: {list(tried_passes)}"
            )
            
            alerts.append({
                'alert_type': 'Brute Force Attack',
                'description': description,
                'severity': 'High (خطير جداً)',
                'ip_source': ip,
                'timestamp': last_time
            })

    # كشف هجوم DDoS
    for ip, count in ip_request_counts.items():
        if count >= 35:
            last_time = datetime.now().strftime("%H:%M:%S %d-%m-%Y")
            description = (
                f"هجوم حجب خدمة موزع (DDoS Attack) قادم من الآيبي ({ip}) "
                f"بإجمالي تدفق بلغ {count} طلب. | آخر رصد: {last_time}"
            )
            if not any(a.get('ip_source') == ip and 'DDoS' in a['alert_type'] for a in alerts):
                alerts.append({
                    'alert_type': 'DDoS Attack (Flood)',
                    'description': description,
                    'severity': 'Critical (حرج للغاية)',
                    'ip_source': ip,
                    'timestamp': last_time
                })
            
    return alerts