import os

def parse_logs():
    logs = []
    log_file_path = 'system.log'
    
    if not os.path.exists(log_file_path):
        return logs
        
    with open(log_file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
                
            parts = line.split(' - ')
            raw_status = parts[0].strip() if len(parts) > 0 else 'UNKNOWN'
            
            if 'FAIL' in raw_status.upper():
                status = 'FAILED_LOGIN'
            else:
                status = raw_status
            
            log_entry = {
                'raw': line,
                'status': status,
                'ip': '',
                'user': '',
                'password': ''
            }
            
            for part in parts:
                part_clean = part.strip()
                if part_clean.startswith('IP:'):
                    log_entry['ip'] = part_clean.replace('IP:', '').strip()
                elif part_clean.startswith('User:'):
                    log_entry['user'] = part_clean.replace('User:', '').strip()
                elif part_clean.startswith('Pass:'):
                    log_entry['password'] = part_clean.replace('Pass:', '').strip()
                    
            logs.append(log_entry)
            
    return logs