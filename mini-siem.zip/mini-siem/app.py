from flask import Flask, render_template, request, redirect, url_for
from database.models import db, LogEntry, Alert
from core.collector import parse_logs
from core.rule_engine import check_brute_force
from datetime import datetime, timedelta
import random
import os

app = Flask(__name__, template_folder='web/templates')
app.secret_key = 'super_secret_key_for_siem'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///siem.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# دالة لتوليد حركة مرور حية (تدعم اللغة العربية بترميز utf-8)
def generate_mock_traffic():
    sample_users = ['يوسف', 'admin', 'root', 'user1', 'ahmed', 'sarah', 'operator', 'guest']
    sample_passes = ['admin123', '123456', 'yousef2026', 'password!', 'toor', 'secret_pass', 'qwerty', 'welcome1']
    sample_ips = ['192.168.1.50', '10.0.0.15', '172.16.0.8', '203.0.113.5', '192.168.100.25', '192.168.1.105']
    
    status_choice = random.choices(['FAILED_LOGIN', 'SUCCESS'], weights=[60, 40])[0]
    
    ip = random.choice(sample_ips)
    user = random.choice(sample_users)
    password = random.choice(sample_passes)
    
    if (user == 'يوسف' and password == 'yousef2026') or (user == 'admin' and password == 'admin123') or (status_choice == 'SUCCESS'):
        log_line = f"SUCCESS - IP:{ip} - User:{user} - Pass:{password} - Status: Authorized\n"
    else:
        log_line = f"FAILED_LOGIN - IP:{ip} - User:{user} - Pass:{password} - Status: Unauthorized\n"
        
    with open('system.log', 'a', encoding='utf-8') as f:
        f.write(log_line)

# 1. موقع الشركة الرسمي
@app.route('/')
def company_home():
    client_ip = request.remote_addr
    log_line = f"PAGE_VIEW - IP:{client_ip} - User:Visitor - Status: Authorized\n"
    with open('system.log', 'a', encoding='utf-8') as f:
        f.write(log_line)
    return render_template('company_home.html')

# 2. زر محاكاة هجوم DDoS
@app.route('/simulate-ddos')
def simulate_ddos():
    attacker_ip = "192.168.100.99"
    with open('system.log', 'a', encoding='utf-8') as f:
        for _ in range(15):
            f.write(f"FLOOD_REQUEST - IP:{attacker_ip} - User:BotNet - Status: Blocked\n")
    return redirect(url_for('dashboard'))

# 3. لوحة تحكم عمليات الأمان (SOC Dashboard) مع تحديث التنبيه القديم تلقائياً
@app.route('/dashboard')
def dashboard():
    generate_mock_traffic()
    
    logs_data = parse_logs()
    detected_alerts = check_brute_force(logs_data)
    
    with app.app_context():
        new_alert_detected = False
        for alert_info in detected_alerts:
            ip_src = alert_info.get('ip_source')
            a_type = alert_info['alert_type']
            
            # البحث عن تنبيه سابق لنفس الآيبي ونفس نوع الهجوم
            existing_alert = Alert.query.filter(
                Alert.alert_type == a_type,
                Alert.description.like(f"%({ip_src})%")
            ).order_by(Alert.id.desc()).first()
            
            if existing_alert:
                # تحديث وقت التنبيه والتفاصيل والوقت ليبقى نشطاً ومُحدثاً في الواجهة
                existing_alert.timestamp = alert_info['timestamp']
                existing_alert.description = alert_info['description']
                existing_alert.created_at = datetime.now()
            else:
                # إنشاء تنبيه جديد إذا لم يكن موجوداً
                new_alert = Alert(
                    alert_type=alert_info['alert_type'],
                    description=alert_info['description'],
                    severity=alert_info['severity'],
                    timestamp=alert_info['timestamp'],
                    created_at=datetime.now()
                )
                db.session.add(new_alert)
                new_alert_detected = True
                
        db.session.commit()
        
        five_minutes_ago = datetime.now() - timedelta(minutes=5)
        recent_alerts = Alert.query.filter(Alert.created_at >= five_minutes_ago).order_by(Alert.id.desc()).all()
        
        all_stored_alerts = Alert.query.order_by(Alert.id.desc()).all()
        total_logs = len(logs_data)
        failed_count = sum(1 for log in logs_data if log['status'] == 'FAILED_LOGIN')
        alerts_count = len(all_stored_alerts)

    return render_template(
        'dashboard.html', 
        logs=logs_data, 
        alerts=recent_alerts, 
        total_logs=total_logs,
        failed_count=failed_count,
        alerts_count=alerts_count
    )

# 4. صفحة سجل التنبيهات الخاصة (الأرشيف)
@app.route('/alerts')
def alerts_page():
    with app.app_context():
        all_alerts = Alert.query.order_by(Alert.id.desc()).all()
    return render_template('alerts.html', alerts=all_alerts)

# 5. بوابة تسجيل الدخول للشركة
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        client_ip = request.remote_addr
        
        if (username == 'admin' and password == 'admin123') or (username == 'يوسف' and password == 'yousef2026'):
            log_line = f"SUCCESS - IP:{client_ip} - User:{username} - Pass:{password} - Status: Authorized\n"
            with open('system.log', 'a', encoding='utf-8') as f:
                f.write(log_line)
            return redirect(url_for('company_home'))
        else:
            log_line = f"FAILED_LOGIN - IP:{client_ip} - User:{username} - Pass:{password} - Status: Unauthorized\n"
            with open('system.log', 'a', encoding='utf-8') as f:
                f.write(log_line)
            error = "اسم المستخدم أو كلمة المرور غير صحيحة، أعد المحاولة!"
            
    return render_template('login.html', error=error)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)