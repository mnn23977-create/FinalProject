from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class LogEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.String(50), default=lambda: datetime.now().strftime("%H:%M:%S %d-%m-%Y"))
    status = db.Column(db.String(50))
    ip = db.Column(db.String(50))
    user = db.Column(db.String(50))
    password = db.Column(db.String(100))

class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    alert_type = db.Column(db.String(100))
    description = db.Column(db.Text)
    severity = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.now)  # لحساب وقت الاختفاء بعد 5 دقائق